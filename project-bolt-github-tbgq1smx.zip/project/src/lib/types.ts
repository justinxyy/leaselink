export interface Listing {
  id: string;
  user_id: string;
  title: string;
  description: string | null;
  price: number;
  location: string;
  latitude: number | null;
  longitude: number | null;
  property_type: string;
  bedrooms: number;
  bathrooms: number;
  square_feet: number | null;
  max_occupancy: number;
  furnished: boolean;
  amenities: string[] | null;
  images: string[] | null;
  start_date: string;
  end_date: string;
  created_at: string;
  updated_at: string;
}

export interface ListingFilters {
  minPrice?: number;
  maxPrice?: number;
  propertyType?: string;
  startDate?: string;
  endDate?: string;
  furnished?: boolean;
  minBedrooms?: number;
  minBathrooms?: number;
}