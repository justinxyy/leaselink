import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Listing, ListingFilters } from "@/lib/types";

export const useListings = () => {
  const queryClient = useQueryClient();

  // Fetch all listings with optional filters
  const useAllListings = (filters?: ListingFilters) => {
    return useQuery({
      queryKey: ["listings", filters],
      queryFn: async () => {
        let query = supabase
          .from("listings")
          .select("*")
          .order("created_at", { ascending: false });

        // Apply filters if they exist
        if (filters) {
          if (filters.minPrice) {
            query = query.gte("price", filters.minPrice);
          }
          if (filters.maxPrice) {
            query = query.lte("price", filters.maxPrice);
          }
          if (filters.propertyType) {
            query = query.eq("property_type", filters.propertyType);
          }
          if (filters.startDate) {
            query = query.gte("start_date", filters.startDate);
          }
          if (filters.endDate) {
            query = query.lte("end_date", filters.endDate);
          }
          if (filters.furnished !== undefined) {
            query = query.eq("furnished", filters.furnished);
          }
          if (filters.minBedrooms) {
            query = query.gte("bedrooms", filters.minBedrooms);
          }
          if (filters.minBathrooms) {
            query = query.gte("bathrooms", filters.minBathrooms);
          }
        }

        const { data, error } = await query;

        if (error) {
          throw error;
        }

        return data as Listing[];
      },
    });
  };

  // Fetch a single listing by ID
  const useListingById = (id: string | undefined) => {
    return useQuery({
      queryKey: ["listings", id],
      queryFn: async () => {
        if (!id) return null;

        const { data, error } = await supabase
          .from("listings")
          .select("*")
          .eq("id", id)
          .single();

        if (error) {
          throw error;
        }

        return data as Listing;
      },
      enabled: !!id,
    });
  };

  // Fetch listings by user ID
  const useUserListings = (userId: string | undefined) => {
    return useQuery({
      queryKey: ["listings", "user", userId],
      queryFn: async () => {
        if (!userId) return [];

        const { data, error } = await supabase
          .from("listings")
          .select("*")
          .eq("user_id", userId)
          .order("created_at", { ascending: false });

        if (error) {
          throw error;
        }

        return data as Listing[];
      },
      enabled: !!userId,
    });
  };

  // Create a new listing
  const useCreateListing = () => {
    return useMutation({
      mutationFn: async (listing: Omit<Listing, "id" | "created_at" | "updated_at">) => {
        const { data: { user } } = await supabase.auth.getUser();
        
        if (!user) {
          throw new Error("You must be signed in to create a listing");
        }

        const listingWithUserId = {
          ...listing,
          user_id: user.id
        };

        const { data, error } = await supabase
          .from("listings")
          .insert(listingWithUserId)
          .select()
          .single();

        if (error) {
          throw error;
        }

        return data as Listing;
      },
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: ["listings"] });
      },
    });
  };

  // Update an existing listing
  const useUpdateListing = () => {
    return useMutation({
      mutationFn: async ({ id, ...listing }: Partial<Listing> & { id: string }) => {
        const { data: { user } } = await supabase.auth.getUser();
        
        if (!user) {
          throw new Error("You must be signed in to update a listing");
        }

        const { data, error } = await supabase
          .from("listings")
          .update(listing)
          .eq("id", id)
          .eq("user_id", user.id) // Ensure user owns the listing
          .select()
          .single();

        if (error) {
          throw error;
        }

        return data as Listing;
      },
      onSuccess: (data) => {
        queryClient.invalidateQueries({ queryKey: ["listings"] });
        queryClient.invalidateQueries({ queryKey: ["listings", data.id] });
      },
    });
  };

  // Delete a listing
  const useDeleteListing = () => {
    return useMutation({
      mutationFn: async (id: string) => {
        const { data: { user } } = await supabase.auth.getUser();
        
        if (!user) {
          throw new Error("You must be signed in to delete a listing");
        }

        const { error } = await supabase
          .from("listings")
          .delete()
          .eq("id", id)
          .eq("user_id", user.id); // Ensure user owns the listing

        if (error) {
          throw error;
        }

        return id;
      },
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: ["listings"] });
      },
    });
  };

  return {
    useAllListings,
    useListingById,
    useUserListings,
    useCreateListing,
    useUpdateListing,
    useDeleteListing,
  };
};