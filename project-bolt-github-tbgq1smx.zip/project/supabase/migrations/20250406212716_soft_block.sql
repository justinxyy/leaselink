/*
  # Create listings schema

  1. New Tables
    - `listings`
      - Core listing information
      - Location data
      - Property details
      - Availability and pricing
      - Timestamps and user reference

  2. Security
    - Enable RLS
    - Add policies for CRUD operations
    - Ensure authenticated users can manage their listings
*/

-- Create listings table
CREATE TABLE IF NOT EXISTS public.listings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id),
  title text NOT NULL,
  description text,
  price numeric NOT NULL CHECK (price >= 0),
  location text NOT NULL,
  latitude numeric,
  longitude numeric,
  property_type text NOT NULL,
  bedrooms integer NOT NULL CHECK (bedrooms >= 0),
  bathrooms numeric NOT NULL CHECK (bathrooms >= 0),
  square_feet integer CHECK (square_feet >= 0),
  max_occupancy integer NOT NULL CHECK (max_occupancy >= 1),
  furnished boolean DEFAULT false,
  amenities text[],
  images text[],
  start_date date NOT NULL,
  end_date date NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT end_date_after_start_date CHECK (end_date > start_date)
);

-- Enable Row Level Security
ALTER TABLE public.listings ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can view listings"
  ON public.listings
  FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can create listings"
  ON public.listings
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own listings"
  ON public.listings
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own listings"
  ON public.listings
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create updated_at trigger
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_listings_updated_at
  BEFORE UPDATE ON public.listings
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Insert test listings
INSERT INTO public.listings (
  title,
  description,
  price,
  location,
  latitude,
  longitude,
  property_type,
  bedrooms,
  bathrooms,
  square_feet,
  max_occupancy,
  furnished,
  amenities,
  images,
  start_date,
  end_date
) VALUES 
(
  'Test1 - Modern Studio Near Campus',
  'Test listing 1: A beautiful studio apartment perfect for students.',
  1200,
  'Berkeley, CA',
  37.8715,
  -122.2730,
  'Studio',
  1,
  1,
  450,
  2,
  true,
  ARRAY['Wifi', 'Kitchen', 'Laundry'],
  ARRAY['https://images.unsplash.com/photo-1522708323590-d24dbb6b0267'],
  '2024-06-01',
  '2024-08-15'
),
(
  'Test2 - Cozy 1BR Apartment',
  'Test listing 2: Comfortable one-bedroom apartment in a quiet neighborhood.',
  1500,
  'Palo Alto, CA',
  37.4419,
  -122.1430,
  'Apartment',
  1,
  1,
  600,
  2,
  true,
  ARRAY['Wifi', 'Kitchen', 'Parking'],
  ARRAY['https://images.unsplash.com/photo-1560448204-e02f11c3d0e2'],
  '2024-05-15',
  '2024-08-30'
),
(
  'Test3 - Shared Student House',
  'Test listing 3: Private room in a shared student house.',
  900,
  'Ann Arbor, MI',
  42.2808,
  -83.7430,
  'Private Room',
  1,
  1.5,
  200,
  1,
  true,
  ARRAY['Wifi', 'Kitchen', 'Laundry', 'Parking'],
  ARRAY['https://images.unsplash.com/photo-1502672260266-1c1ef2d93688'],
  '2024-06-01',
  '2024-07-31'
),
(
  'Test4 - Downtown Studio',
  'Test listing 4: Modern studio in the heart of downtown.',
  1800,
  'New York, NY',
  40.7128,
  -74.0060,
  'Studio',
  1,
  1,
  400,
  2,
  true,
  ARRAY['Wifi', 'Kitchen', 'Gym'],
  ARRAY['https://images.unsplash.com/photo-1598928506311-c55ded91a20c'],
  '2024-05-20',
  '2024-08-10'
),
(
  'Test5 - Campus View Apartment',
  'Test listing 5: Spacious apartment with amazing campus views.',
  1350,
  'Cambridge, MA',
  42.3736,
  -71.1097,
  'Apartment',
  2,
  1,
  800,
  3,
  true,
  ARRAY['Wifi', 'Kitchen', 'Laundry', 'Parking'],
  ARRAY['https://images.unsplash.com/photo-1554995207-c18c203602cb'],
  '2024-06-15',
  '2024-08-20'
);